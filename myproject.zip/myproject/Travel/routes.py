# routes.py
from flask import flash, render_template, request, redirect, session, url_for, Blueprint
from Travel.model import Flight, Hotel
from Travel import db

bp = Blueprint('travel', __name__)



@bp.route('/')
def show():
    return render_template("home.html")

@bp.route('/login/admin', methods=['GET', 'POST'])
def adminLogin():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        # Validate the credentials
        if email == 'admin@gmail.com' and password == 'admin':
            session['admin_logged_in'] = True
            return redirect(url_for('travel.admin_dashboard'))  # Correct redirect with blueprint prefix
        else:
            flash('Invalid username or password')  # Use flash to send an error message
            return redirect(url_for('travel.user_dashboard'))  # Redirect back to the login page
    
    return render_template('admin_login.html')

@bp.route('/admin/dashboard')
def admin_dashboard():
    # Check if the admin is logged in
    if not session.get('admin_logged_in'):
        return redirect(url_for('travel.login'))  # Redirect to login if not logged in

    return render_template('admin_dashboard.html')

@bp.route('/user/dashboard')
def user_dashboard():
    # Check if the user is logged in
    if not session.get('user_logged_in'):
        return redirect(url_for('travel.login'))  # Redirect to login if not logged in
    
    return render_template('user_dashboard.html')


@bp.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        # Check for admin credentials
        if email == 'admin@gmail.com' and password == 'admin':
            # Redirect to admin dashboard
            return redirect(url_for('admin_dashboard'))
        else:
            # Redirect to user dashboard
            return redirect(url_for('user_dashboard'))

    return render_template('login.html')

@bp.route('/register')
def register():
    return render_template("registration.html")

@bp.route('/flights')
def flights():
    flights = Flight.query.all()
    return render_template('flight_avail.html', flights=flights)


from datetime import datetime
@bp.route('/book/flight', methods=['GET', 'POST'])
def book_flight():
    if request.method == 'POST':
        service_id = request.form.get('f_id')
        Flight_Name = request.form.get('Flight_Name')
        From = request.form.get('From')
        To = request.form.get('To')
        Departure = request.form.get('Departure')
        Return = request.form.get('Return')
        price = request.form.get('price')
        availability_count = request.form.get('availability_count')

        if Departure:
            Departure = datetime.strptime(Departure, '%Y-%m-%d').date()  # Convert string to date
        if Return:
            if Return.strip():  # Check if Return is not just whitespace
                Return = datetime.strptime(Return, '%Y-%m-%d').date()  # Convert string to date
            else:
                Return = None   # If Return is empty or invalid


        if service_id and Flight_Name and price:
            flight = Flight(
                service_id=service_id,
                Flight_Name=Flight_Name,
                From=From,
                To=To,
                Departure=Departure,
                Return=Return,
                availability_count=availability_count,
                price=price
            )
            db.session.add(flight)
            db.session.commit()
            return redirect(url_for('travel.book_flight'))  # Redirect without flights

    flights = Flight.query.all()
    return render_template('flight.html', flights=flights)

@bp.route('/search/flight', methods=['GET', 'POST'])
def search_flight():
    if request.method == 'POST':
        From = request.form.get('From')
        To = request.form.get('To')
        flights = Flight.query.filter_by(From=From, To=To).all()
        return render_template('flight_avail.html', flights=flights)

    return render_template('flight_search.html')

@bp.route('/edit/flight/<int:id>', methods=['GET', 'POST'])
def edit_flight(id):
    flight = Flight.query.get_or_404(id)
    if request.method == 'POST':
        flight.service_id = request.form.get('service_id')  # Use service_id
        flight.Flight_Name = request.form.get('Flight_Name')
        flight.From = request.form.get('From')
        flight.To = request.form.get('To')
        flight.Departure = request.form.get('Departure')
        flight.Return = request.form.get('Return')
        flight.price = request.form.get('price')  # Lowercase 'price'
        flight.availability_count = request.form.get('availability_count')  # Update availability count

        try:
            db.session.commit()
            return redirect(url_for('travel.flights'))
        except Exception as e:
            db.session.rollback()
            print(f"Error occurred while editing flight: {e}")

    return render_template('edit_flight.html', flight=flight)




@bp.route('/hotels')
def hotels():
    hotels = Hotel.query.all()
    return render_template('hotel_avail.html', hotels=hotels)

@bp.route('/book/hotel', methods=['GET', 'POST'])
def book_hotel():
    if request.method == 'POST':
        service_id = request.form.get('service_id')
        Destination = request.form.get('Destination')
        Hotel_Name = request.form.get('Hotel_Name')
        Check_In = request.form.get('Check_In')
        Check_Out = request.form.get('Check_Out')
        availability_count = request.form.get('availability_count')
        price = request.form.get('price')

        
        hotel = Hotel(
            service_id=service_id,  # Or whatever logic you use to set this
            Destination=Destination,
            Hotel_Name=Hotel_Name,
            Check_In=Check_In,
            Check_Out=Check_Out,
            availability_count=availability_count,
            price=price
        )
        db.session.add(hotel)
        db.session.commit()
        return redirect(url_for('travel.book_hotel'))

    hotels = Hotel.query.all()
    return render_template("hotel.html", hotels=hotels)

@bp.route('/search/hotel', methods=['GET', 'POST'])
def search_hotel():
    if request.method == 'POST':
        Destination = request.form.get('destination')
        hotels = Hotel.query.filter_by(Destination=Destination).all()
        return render_template('hotel_avail.html', hotels=hotels)

    return render_template('hotel_search.html')

@bp.route('/edit/hotel/<int:id>', methods=['GET', 'POST'])
def edit_hotel(id):
    hotel = Hotel.query.get_or_404(id)
    if request.method == 'POST':
        hotel.service_id = request.form.get('service_id')
        hotel.Destination = request.form.get('Destination')
        hotel.Hotel_Name = request.form.get('Hotel_Name')
        hotel.Check_In = request.form.get('Check_In')
        hotel.Check_Out = request.form.get('Check_Out')
        hotel.availability_count = request.form.get('availability_count')
        hotel.price = request.form.get('price')

        try:
            db.session.commit()
            return redirect(url_for('travel.hotels'))
        except Exception as e:
            db.session.rollback()
            print(f"Error occurred while editing hotel: {e}")

    return render_template('edit_hotel.html', hotel=hotel)

@bp.route('/my_reservations')
def my_reservations():
    flights = Flight.query.all()
    hotels = Hotel.query.all()
    return render_template('reservations.html', flights=flights, hotels=hotels)

@bp.route('/cancel/flight/<int:id>')
def cancel_flight(id):
    flight = Flight.query.get_or_404(id)
    db.session.delete(flight)
    db.session.commit()
    return redirect(url_for('travel.flights'))

@bp.route('/cancel/hotel/<int:id>')
def cancel_hotel(id):
    hotel = Hotel.query.get_or_404(id)
    db.session.delete(hotel)
    db.session.commit()
    return redirect(url_for('travel.hotels'))


@bp.route('/check_availability')
def check_availability():
    available_flights = Flight.query.filter_by(availability=True).all()
    available_hotels = Hotel.query.filter_by(availability=True).all()
    return render_template('availability.html', flights=available_flights, hotels=available_hotels)



