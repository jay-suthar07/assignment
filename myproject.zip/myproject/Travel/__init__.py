from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///database.db"
db = SQLAlchemy(app)

# Ensure app context for database operations
app.app_context().push()

# Import models
from Travel.model import *

app.secret_key = 'your_secret_key_here'

def create_app():
    # Register the blueprint from routes
    from Travel.routes import bp
    app.register_blueprint(bp)
    
    # Ensure tables are created
    with app.app_context():
        db.create_all()  # This ensures the tables are created before any requests are processed
    
    return app