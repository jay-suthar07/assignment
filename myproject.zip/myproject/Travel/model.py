# model.py
# from flask_sqlalchemy import SQLAlchemy
from Travel import db

class TravelService(db.Model):
    __abstract__ = True  # This class will not create a table
    id = db.Column(db.Integer,primary_key=True)
    service_id = db.Column(db.Integer)
    availability_count = db.Column(db.Integer, default=0)  # Availability count
    price = db.Column(db.Float, nullable=False)

    def __repr__(self):
        return f'<{self.__class__.__name__} {self.service_id}>'

from datetime import datetime



class Flight(TravelService):
    __tablename__ = 'flights'
    id = db.Column(db.Integer, primary_key=True)
    Flight_Name = db.Column(db.String(80), nullable=False)
    From = db.Column(db.String(80), nullable=False)
    To = db.Column(db.String(80), nullable=False)
    Departure = db.Column(db.String(80), nullable=False)
    Return = db.Column(db.String(80), nullable=True)
    

    def __repr__(self):
        return f'<Flight {self.Flight_Name}>'



class Hotel(TravelService):
    __tablename__ = 'hotels'
    id = db.Column(db.Integer, primary_key=True)
    Destination = db.Column(db.String(80), nullable=False)
    Hotel_Name = db.Column(db.String(80), nullable=False)
    Check_In = db.Column(db.String(80), nullable=False)
    Check_Out = db.Column(db.String(80), nullable=False)
    

    def __repr__(self):
        return f'<Hotel {self.Hotel_Name}>'

class PackageDeal(db.Model):
    __tablename__ = 'package_deals'

    package_id = db.Column(db.Integer, primary_key=True)
    package_name = db.Column(db.String(80), nullable=False)

    # Foreign keys to Flight and Hotel
    flight_id = db.Column(db.Integer, db.ForeignKey('flights.service_id'), nullable=False)
    hotel_id = db.Column(db.Integer, db.ForeignKey('hotels.service_id'), nullable=False)

    # Relationships to allow access to Flight and Hotel objects
    flight = db.relationship('Flight', backref='package_deals', lazy=True)
    hotel = db.relationship('Hotel', backref='package_deals', lazy=True)


    def total_price(self):
        total = self.flight.price + self.hotel.price 
        return total
    
    def __repr__(self):
        return f'<PackageDeal {self.package_name} - Flight ID {self.flight_id} - Hotel ID {self.hotel_id}>'